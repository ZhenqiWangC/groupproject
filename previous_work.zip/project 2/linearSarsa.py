import gym
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


def linear_Sarsa():
    total_rewards=[]
    env = gym.make('LunarLander-v2')
    w=np.array([[0 for _ in range(8)] for _ in range(4)])
    for iteration in range(10000):
        state = env.reset()
        total_reward=0
        epsilon = min_e + (max_e - min_e)*np.exp(-decay_rate*iteration)
        alpha = min_a + (max_a - min_a)*np.exp(-decay_rate*iteration)
        done=False
        random_value = np.random.random()
        if random_value<=epsilon:
            action = env.action_space.sample()
        else:
            Y=np.dot(w,state)
            action = np.argmax(Y)
        while not done:
            new_state, reward, done, info = env.step(action)
            total_reward+=reward
            random_value = np.random.random()
            if random_value<=epsilon:
                new_action = env.action_space.sample()
            else:
                Y=np.dot(w,new_state)
                new_action = np.argmax(Y)
            if done:
                target = reward
            else:
                Y=np.dot(w,new_state)
                target = reward +gamma*Y[new_action]

            X=state.reshape(1,-1)
            Y=np.dot(w,state)
            Y_target = np.dot(w,state)
            Y_target[action] = target
            w = w+learning_rate*(Y_target[action]-Y[action])*state
            state = new_state
            action =new_action
        total_rewards.append(total_reward)
#         try:
#             print('episode: ', iteration, ' score: ', '%.2f' % total_reward, ' avg_score: ', '%.2f' % np.average(total_rewards[-100:]),'%.5f' % epsilon)
#         except:
#             print('episode: ', iteration, ' score: ', '%.2f' % total_reward, ' avg_score: ', '%.2f' % np.average(total_rewards),'%.5f' % epsilon)
    return w, total_rewards

def evaluate(w,test_episodes=100):
    test_rewards=[]
    for i in range(test_episodes):
        rewards=0
        done = False
        state=env.reset()
        while not done:
            Y=np.dot(w,state)
            action = np.argmax(Y)
            new_state, reward, done, info = env.step(action)
            rewards+=reward
            state=new_state
        test_rewards.append(rewards)
        #print(i,rewards)
    return test_rewards

def running_mean(x, N):
    cumsum = np.cumsum(np.insert(x, 0, 0)) 
    return (cumsum[N:] - cumsum[:-N]) / float(N)


def random_baseline(test_episodes=1000):
    random_rewards=[]
    for i in range(test_episodes):
        rewards=0
        done = False
        state=env.reset()
        while not done:
            action = np.random.choice(4)
            new_state, reward, done, info = env.step(action)
            rewards+=reward
            state=new_state
        random_rewards.append(rewards)
        #print(i,rewards)
    return random_rewards


if __name__=="__main__":
    gamma = 0.9
    decay_rate = 5e-4
    max_e=1
    min_e=1e-4
    max_a=0.01
    min_a=1e-5
    w,total_rewards=linear_Sarsa()
    test_rewards = evaluate(w)