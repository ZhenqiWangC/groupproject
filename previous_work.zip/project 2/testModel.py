import gym, random, tempfile
import numpy as np
from gym import wrappers
from collections import deque
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam

def initiate_NN(learning_rate=1e-3):
    model = Sequential()
    model.add(Dense(64, input_dim=8, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(4, activation='linear'))
    model.compile(loss='mse', optimizer=Adam())
    return model

def initiate_NN_single(learning_rate=1e-3):
    model = Sequential()
    model.add(Dense(64, input_dim=8, activation='relu'))
    model.add(Dense(4, activation='linear'))
    model.compile(loss='mse', optimizer=Adam())
    return model

def evaluate(model,test_episodes=100):
    test_rewards=[]
    for i in range(test_episodes):
        rewards=0
        done = False
        state=env.reset()
        while not done:
            Y=model.predict(state.reshape(1,-1))
            action = Y[0].tolist().index(np.max(Y))
            new_state, reward, done, info = env.step(action)
            rewards+=reward
            state=new_state
        test_rewards.append(rewards)
        #print(i,rewards)
    return test_rewards

if __name__=='__main__':
    env = gym.make('LunarLander-v2')
    gamma = 0.9
    decay_rate = 0.002
    max_e=1
    min_e=0.0001
    learning_rate =0.005
    model = initiate_NN2(learning_rate) 
    model_string='/DQLEARN_'+str(max_e)+'-'+str(min_e)+'-'+str(decay_rate)+'-'+str(gamma)+'-'+str(learning_rate)
    model.load_weights('weights'+model_string+'.h5')
    test_rewards =evaluate(model)
    import pickle
    with open('rewards/test'+model_string+'.json', 'wb') as fp:
        pickle.dump({'test_rewards':test_rewards}, fp)

